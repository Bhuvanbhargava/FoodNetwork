The project is using an embedded test "data.csv" file if you wish to use that default file.Just run the program and press enter when asked to provide the file location. 

If you wish to use a file from different location, provide the directory location of that file when asked. The output files will be created in the same directory as well.

Filehandler class is covered through the test cases pretty good and to test it try commenting any one line in the file and at least one test should fail.

Program.cs file have no unit test as the functions under that file are only File I/O operation and in my view developer should focus on the Logic what he has written for expected outcome of the program. 

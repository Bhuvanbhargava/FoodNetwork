﻿using System;
using System.IO;
using System.Linq;

namespace CSVFileHandler
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*****************************************************");
            Console.WriteLine("This project using the embeded data.csv file in case no file or location provided");
            Console.WriteLine("*****************************************************");
            DirectoryInfo dirinfo =null;
            FileInfo[] files = null;
            bool isCSVFilesExist = false;
            while (!isCSVFilesExist)
            {
                dirinfo = AskFileLocation();
                if (!dirinfo.Exists)
                {
                    Console.WriteLine("Directory {0} does not exist.", dirinfo.FullName);
                    Console.WriteLine();
                    continue;
                }
                files = CheckForCSVFileInDirectory(dirinfo);
                if (files.Length == 0)
                {
                    Console.WriteLine("no csv file fount at {0}", dirinfo.FullName);
                    Console.WriteLine();
                }
                else { 
                    isCSVFilesExist= true;
                }
            }
            bool isValidFileSelected = false;
            int selectedFileId=-1;
            while (!isValidFileSelected)
            {
                int counter = 1;
                Console.WriteLine("Please enter a number in front of the corrospoding file to select");
                foreach (var file in files)
                {
                    Console.WriteLine("{0} - {1}", counter++, file.Name);

                }
                --counter;//decrease the additonl counter to maintain the index;
               
                int.TryParse(Console.ReadLine(), out selectedFileId);
                if (selectedFileId > counter || selectedFileId <= 0)
                {
                    continue;
                }
                isValidFileSelected = true;
            }
            var selectedFile = files[--selectedFileId];
            Console.WriteLine("Ok! processing ({0}) file.", selectedFile);

            var result = StartFileProcessing(selectedFile);

            CreateFile(dirinfo.FullName, result);

            Console.ReadLine();
        }

        private static FileInfo[] CheckForCSVFileInDirectory(DirectoryInfo dirinfo)
        {
            FileInfo[] files = dirinfo.GetFiles("*.csv");
            return files;
           
        }

        private static DirectoryInfo AskFileLocation()
        {
            Console.WriteLine("Please specify file location or press enter to use default embedded file");

            var filePath = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(filePath))
            {
                filePath = @"..\..\Files";
            }
           var dirinfo = new DirectoryInfo(filePath);
           return dirinfo;
        }

        private static void CreateFile(string filePath, ResultViewModel result)
        {
            var frequencyFile = string.Format("{0}\\OrderNamesbyFreqAndAlph.txt", filePath);
            var addressFile = string.Format("{0}\\OrderAddressAlph.txt", filePath);
            File.WriteAllLines(frequencyFile, result.FrequencyResult.Select(a=>a.Item));
            File.WriteAllLines(addressFile, result.AddressResult.Select(a => a.Address));
            Console.WriteLine();
            Console.WriteLine("********Files are saved at ({0}).**********", filePath);
        }

        public static ResultViewModel StartFileProcessing(FileInfo file)
        {            
            using (FileStream fileStream = File.OpenRead(file.FullName))
            {             
                MemoryStream memoryStream = new MemoryStream();
                memoryStream.SetLength(fileStream.Length);               
                fileStream.Read(memoryStream.GetBuffer(), 0, (int)fileStream.Length);
                FileHandler fh = new FileHandler();
                var result=fh.ProcessFile(memoryStream);

                //Print the FrequencyResult
                Console.WriteLine();
                Console.WriteLine("Order name and lastname by frequency than alphabet");
                foreach (var item in result.FrequencyResult)
                {
                    Console.WriteLine("{0} - {1}", item.Item, item.Frequency);
                }
                ;
                // Print the AddressResult
                Console.WriteLine();
                Console.WriteLine("Order address by alphabet");
                foreach (var item in result.AddressResult)
                {
                    Console.WriteLine("{0} ", item.Address);
                }
                return result;
            }            
        }
    }
}

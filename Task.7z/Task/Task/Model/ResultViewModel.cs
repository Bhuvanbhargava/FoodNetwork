﻿using System.Collections.Generic;


namespace CSVFileHandler
{
    public class ResultViewModel
    {
        public List<FrequencyModel> FrequencyResult { get; set; }
        public List<AddressModel> AddressResult { get; set; }
    }
}

﻿namespace CSVFileHandler
{
    public class AddressModel
    {
        public string Address { get; set; }
        public string SortString { get; set; }
    }
}

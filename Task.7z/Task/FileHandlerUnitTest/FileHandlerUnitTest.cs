﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CSVFileHandler.UnitTest
{
    [TestClass]
    public class FileHandlerUnitTest
    {
        private string _rawData;
        private FileHandler _fileHandler;
        [TestMethod] 
        public void ProcessFile_validFiledata_returnNamesInFrequencyOrder()
        {
            using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(_rawData)))
            {
                var result = _fileHandler.ProcessFile(stream);
                Assert.IsNotNull(result);
                Assert.IsNotNull(result.FrequencyResult);       
                Assert.AreEqual(9, result.FrequencyResult.Count);
                List<string> actual = result.FrequencyResult.Select(a => a.Item).ToList();
                Assert.IsTrue(varifyFrequencyOrder(actual));
            }           
        }

        [TestMethod]
        public void ProcessFile_validFiledata_returnAddressInAlphabetOrder()
        {
            using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(_rawData)))
            {
                var result = _fileHandler.ProcessFile(stream);
                Assert.IsNotNull(result);
                Assert.IsNotNull(result.AddressResult);
                Assert.AreEqual(9, result.AddressResult.Count);
                List<string> actual = result.AddressResult.Select(a => a.Address).ToList();
                Assert.IsTrue(varifyAddressOrder(actual));
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ProcessFile_inValidFiledata_returnAddressInAlphabetOrder()
        {
            using (var stream = new MemoryStream(Encoding.UTF8.GetBytes("")))
            {
                _fileHandler.ProcessFile(stream);
            }
        }

        private bool varifyFrequencyOrder(List<string> actual)
        {
            return (actual.IndexOf("bhuvan") == 0 &&
                    actual.IndexOf("sharma") == 1 &&
                    actual.IndexOf("bob") == 2 &&
                    actual.IndexOf("calvin") == 3 &&
                    actual.IndexOf("hue") == 4 &&
                    actual.IndexOf("jerry") == 5 &&
                    actual.IndexOf("omkar") == 6 &&
                    actual.IndexOf("jagtap") == 7 &&
                    actual.IndexOf("joseph") == 8);

        }

        private bool varifyAddressOrder(List<string> actual)
        {
            return (actual.IndexOf("65 ambling way") == 0 &&
            actual.IndexOf("8 crimson rd") == 1 &&
            actual.IndexOf("12 howard st") == 2 &&
            actual.IndexOf("102 long lane") == 3 &&
            actual.IndexOf("94 roland st") == 4 &&
            actual.IndexOf("78 short lane") == 5 &&
            actual.IndexOf("82 stewart st") == 6 &&
            actual.IndexOf("49 sutherland st") == 7 &&
            actual.IndexOf("23-4 5 you at street") == 8);


        }

        [TestInitialize]
        public void TestInitialize()
        {
            _rawData =
           @"FirstName,LastName,Address,PhoneNumber
            Joseph,Sharma,102 Long Lane,29384857
            CALVIN,Omkar,65 Ambling Way,31214788
            Jerry,bob,82 Stewart St,32114566
            bhuvan,hue,12 Howard St,8766556
            Jagtap,hue,78 Short Lane,29384857
            Calvin,Sharma,49 Sutherland St,31214788
            Jerry,Omkar,8 Crimson Rd,32114566
            bhuvan,bob,94 Roland St,8766556
            bhuvan,Sharma,23-4 5 You at street,87878787";

            _fileHandler = new FileHandler();
        }
    }
}
